<html>
	<head>
		<title>fpBatis Examples</title>
	</head>
	<body>
		<a href="list_example.php">List Example</a><br/>
		<a href="create_example.php">Create Example</a>
	</body>
</html>